

# MC-01: Environment versions (matches the mini-course)
import sys, scipy, numpy, pandas, matplotlib, sklearn
print("Python:", sys.version)
print("SciPy:", scipy.__version__)
print("NumPy:", numpy.__version__)
print("Pandas:", pandas.__version__)
print("Matplotlib:", matplotlib.__version__)
print("scikit-learn:", sklearn.__version__)
